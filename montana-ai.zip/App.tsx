
import React from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import NurseryFeatures from './components/NurseryFeatures';
import Technology from './components/Technology';
import Biodiversity from './components/Biodiversity';
import DataDashboards from './components/DataDashboards';
import Articles from './components/Articles';
import Contact from './components/Contact';
import Footer from './components/Footer';

const App: React.FC = () => {
  return (
    <>
      <Header />
      <main>
        <Hero />
        <NurseryFeatures />
        <Technology />
        <Biodiversity />
        <DataDashboards />
        <Articles />
        <Contact />
      </main>
      <Footer />
    </>
  );
};

export default App;
