import React from 'react';
import Reveal from './Reveal';

const DataDashboards: React.FC = () => {
  return (
    <section id="data" className="py-16 md:py-24">
      <div className="max-w-screen-xl mx-auto px-6">
        <Reveal>
          <h2 className="font-display text-3xl md:text-4xl font-bold">Data Publik & Dashboard</h2>
        </Reveal>
        <Reveal>
          <p className="mt-3 text-lg text-muted max-w-2xl leading-relaxed">
            Cuplikan publik dari data yang dapat dibagikan untuk transparansi.
          </p>
        </Reveal>
        <div className="mt-12 grid grid-cols-1 lg:grid-cols-2 gap-8">
          <Reveal>
            <iframe 
              className="aspect-video w-full border-0 rounded-2xl shadow-xl shadow-black/10"
              title="Laporan Bibit - Looker Studio" 
              loading="lazy" 
              src="https://lookerstudio.google.com/embed/reporting/0b55d71c-8b53-4395-8669-216957861962/page/6zXD"
              allowFullScreen>
            </iframe>
          </Reveal>
          <Reveal>
            <iframe 
              className="aspect-video w-full border-0 rounded-2xl shadow-xl shadow-black/10"
              title="Rencana Penanaman 2025 - Google Earth" 
              loading="lazy" 
              src="https://earth.google.com/web/@-2.9304323,115.1438902,34.0205869a,25000d,35y,0h,0t,0r/data=Migrator"
              allowFullScreen>
            </iframe>
          </Reveal>
        </div>
      </div>
    </section>
  );
};

export default DataDashboards;