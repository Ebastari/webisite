import React, { useState, useEffect, useRef } from 'react';
import Reveal from './Reveal';

const slides = [
  { src: 'https://images.unsplash.com/photo-1508514177221-188b2cf16a7d?auto=format&fit=crop&w=1920&q=80', alt: 'Lahan reklamasi yang luas menghijau dengan panel surya' },
  { src: 'https://images.unsplash.com/photo-1505819346363-48e02d5d5498?auto=format&fit=crop&w=1920&q=80', alt: 'Drone terbang di atas hutan untuk pemantauan ekologis' },
  { src: 'https://images.unsplash.com/photo-1476231682828-37e571bc172f?auto=format&fit=crop&w=1920&q=80', alt: 'Matahari terbit di atas lahan hijau subur' },
];

const Slider: React.FC = () => {
    const [current, setCurrent] = useState(0);

    useEffect(() => {
        const interval = setInterval(() => {
            setCurrent(prev => (prev === slides.length - 1 ? 0 : prev + 1));
        }, 6000);
        return () => clearInterval(interval);
    }, []);

    return (
      <div className="absolute inset-0">
        {slides.map((slide, index) => (
          <div
            key={index}
            className={`absolute inset-0 bg-cover bg-center transition-opacity duration-1000 ease-in-out ${index === current ? 'opacity-100' : 'opacity-0'}`}
            style={{ backgroundImage: `url('${slide.src}')` }}
            aria-label={slide.alt}
          ></div>
        ))}
        <div className="absolute left-1/2 -translate-x-1/2 bottom-5 flex gap-2 z-[3]">
            {slides.map((_, i) => (
                <button key={i} onClick={() => setCurrent(i)} className={`w-3 h-3 rounded-full transition-colors ${i === current ? 'bg-brand-2' : 'bg-white/60 hover:bg-white/80'}`}></button>
            ))}
        </div>
      </div>
    );
};

const Hero: React.FC = () => {
  const [useSlider, setUseSlider] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);

  useEffect(() => {
    const videoElement = videoRef.current;
    if (videoElement) {
        const playPromise = videoElement.play();
        if (playPromise !== undefined) {
            playPromise.catch(error => {
                // Autoplay was prevented.
                console.warn("Video autoplay prevented. Falling back to slider.", error);
                setUseSlider(true);
            });
        }
        videoElement.addEventListener('error', () => {
             console.warn("Video failed to load. Falling back to slider.");
             setUseSlider(true)
        });
    }
  }, []);

  return (
    <section id="home" className="relative h-[92vh] min-h-[520px] text-white">
      <div className="absolute inset-0 overflow-hidden" aria-hidden="true">
        {useSlider ? (
          <Slider />
        ) : (
          <video
            ref={videoRef}
            autoPlay
            muted
            loop
            playsInline
            poster="https://images.unsplash.com/photo-1508514177221-188b2cf16a7d?auto=format&fit=crop&w=1920&q=80"
            className="absolute inset-0 w-full h-full object-cover"
          >
            <source src="https://videos.pexels.com/video-files/853870/853870-hd.mp4" type="video/mp4" />
          </video>
        )}
        <div className="absolute inset-0 bg-gradient-to-t from-overlay/60 to-overlay"></div>
      </div>
      <div className="relative z-[2] max-w-screen-xl mx-auto px-6 h-full flex flex-col justify-center">
        <div className="max-w-3xl">
          <Reveal>
            <h1 className="font-display font-bold text-4xl md:text-5xl lg:text-6xl !leading-tight [text-shadow:0_2px_8px_rgba(0,0,0,0.3)]">
              Artificial Intelligence for Smart Land Reclamation
            </h1>
          </Reveal>
          <Reveal>
            <p className="mt-4 text-lg text-white/90 max-w-2xl [text-shadow:0_1px_4px_rgba(0,0,0,0.3)] leading-relaxed">
              Platform modern dengan sentuhan eco‑futuristic: analisis daun, pengukuran tinggi otomatis, peta biodiversitas, dan dashboard data — semuanya terintegrasi dan ramah di mata.
            </p>
          </Reveal>
          <Reveal>
            <div className="mt-8 flex gap-4 flex-wrap">
              <a className="inline-flex items-center gap-2 px-5 py-3 rounded-xl border border-transparent font-semibold cursor-pointer transition-transform duration-200 bg-gradient-to-r from-brand to-brand-2 text-[#053a35] shadow-lg shadow-brand/20 hover:-translate-y-0.5 hover:shadow-xl hover:shadow-brand/30" href="#teknologi">
                Pelajari Teknologi
              </a>
              <a className="inline-flex items-center gap-2 px-5 py-3 rounded-xl font-semibold cursor-pointer transition-transform duration-200 bg-white/95 backdrop-blur-sm text-ink shadow-lg shadow-black/5 hover:-translate-y-0.5 hover:bg-white" href="#data">
                Lihat Data Publik
              </a>
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  );
};

export default Hero;