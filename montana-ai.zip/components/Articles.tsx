import React from 'react';
import Reveal from './Reveal';

const articles = [
    {
        title: "Masa Depan Reklamasi: Peran AI dalam Memulihkan Lahan Bekas Tambang",
        excerpt: "Kecerdasan buatan membuka kemungkinan baru dalam memantau dan mengelola proses revegetasi, memastikan keberhasilan ekologis jangka panjang.",
        image: "https://images.unsplash.com/photo-1618472635397-52d83515b3a3?auto=format&fit=crop&w=800&q=80",
        link: "#",
    },
    {
        title: "Studi Kasus: Peningkatan Keberhasilan Tanam dengan Analisis Citra Satelit",
        excerpt: "Dengan data satelit resolusi tinggi dan machine learning, kami dapat mengidentifikasi area tanam optimal dan memprediksi tingkat pertumbuhan.",
        image: "https://images.unsplash.com/photo-1617944204991-50e5ac9787a7?auto=format&fit=crop&w=800&q=80",
        link: "#",
    },
    {
        title: "Mengukur Kesehatan Hutan dari Jarak Jauh Menggunakan Drone dan AI",
        excerpt: "Drone yang dilengkapi sensor multispektral memberikan data akurat tentang kesehatan vegetasi, membantu intervensi dini terhadap hama atau penyakit.",
        image: "https://images.unsplash.com/photo-1527977966376-1c8408f9f11d?auto=format&fit=crop&w=800&q=80",
        link: "#",
    },
];

const Articles: React.FC = () => {
  return (
    <section id="artikel" className="py-16 md:py-24 bg-cream">
      <div className="max-w-screen-xl mx-auto px-6">
        <Reveal>
          <h2 className="font-display text-3xl md:text-4xl font-bold">Artikel & Wawasan</h2>
        </Reveal>
        <Reveal>
          <p className="mt-3 text-lg text-muted max-w-2xl leading-relaxed">
            Baca lebih lanjut tentang inovasi, studi kasus, dan pembaruan dari tim Montana AI.
          </p>
        </Reveal>
        <div className="mt-12 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {articles.map((article, index) => (
            <Reveal key={index}>
              <a href={article.link} className="group block bg-white border border-gray-200/80 rounded-2xl shadow-lg shadow-black/5 overflow-hidden h-full transition-transform duration-300 hover:-translate-y-1 hover:shadow-xl">
                <img loading="lazy" src={article.image} alt={article.title} className="w-full h-48 object-cover" />
                <div className="p-6">
                  <h3 className="text-xl font-semibold text-ink group-hover:text-brand transition-colors">{article.title}</h3>
                  <p className="mt-2 text-muted text-sm">{article.excerpt}</p>
                </div>
              </a>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Articles;