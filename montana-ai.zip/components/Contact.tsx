import React from 'react';
import Reveal from './Reveal';

const Contact: React.FC = () => {
  return (
    <section id="kontak" className="py-16 md:py-24 bg-gradient-to-b from-white to-gray-50/50">
      <div className="max-w-screen-xl mx-auto px-6">
        <Reveal>
          <h2 className="font-display text-3xl md:text-4xl font-bold">Kontak & Kolaborasi</h2>
        </Reveal>
        <Reveal>
          <p className="mt-3 text-lg text-muted max-w-2xl leading-relaxed">
            Tertarik bermitra atau ingin demo langsung? Hubungi tim kami.
          </p>
        </Reveal>
        <Reveal className="mt-12">
          <div className="bg-white border border-gray-200/80 rounded-2xl p-8 shadow-xl shadow-black/5">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="space-y-4">
                <p className="text-muted">Email: <a href="mailto:info@example.com" className="text-ink font-semibold hover:text-brand">info@example.com</a></p>
                <p className="text-muted">WhatsApp: <a href="https://wa.me/6281122220044" rel="nofollow" className="text-ink font-semibold hover:text-brand">+62 811 2222 0044</a></p>
              </div>
              <div className="space-y-4">
                <p className="text-muted">Alamat: PT Energi Batubara Lestari — Rantau, Kalimantan Selatan</p>
                <p>
                    <a className="inline-flex items-center gap-2 px-4 py-2 rounded-xl font-semibold cursor-pointer transition-transform duration-200 bg-white text-ink shadow-md shadow-black/5 border border-gray-200/80 hover:-translate-y-0.5" href="#">
                        Gabung sebagai Mitra Konservasi
                    </a>
                </p>
              </div>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
};

export default Contact;