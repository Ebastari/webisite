import React, { useEffect, useRef, useState } from 'react';
import Reveal from './Reveal';
// Since we are loading Leaflet via CDN, we need to tell TypeScript about the 'L' global variable.
declare const L: any;

const points = [
    {lat:-2.94, lng:115.10, type:'flora', name:'Shorea sp. (Dipterocarpaceae)', status:'Dilindungi'},
    {lat:-2.92, lng:115.15, type:'fauna', name:'Nasalis larvatus (Bekantan)', status:'Endemik'},
    {lat:-2.95, lng:115.18, type:'flora', name:'Acacia mangium', status:'Introduksi'},
    {lat:-2.90, lng:115.12, type:'fauna', name:'Buceros rhinoceros (Enggang Badak)', status:'Dilindungi'},
    {lat:-2.96, lng:115.08, type:'flora', name:'Eusideroxylon zwageri (Ulin)', status:'Dilindungi'},
];

// Custom hook for count-up animation
const useCountUp = (end: number, duration: number = 1500) => {
    const [count, setCount] = useState(0);
    const ref = useRef<HTMLSpanElement>(null);

    useEffect(() => {
        const observer = new IntersectionObserver(
            ([entry]) => {
                if (entry.isIntersecting) {
                    let start = 0;
                    const startTime = performance.now();
                    const animate = (currentTime: number) => {
                        const elapsedTime = currentTime - startTime;
                        const progress = Math.min(elapsedTime / duration, 1);
                        start = Math.floor(progress * end);
                        setCount(start);
                        if (progress < 1) {
                            requestAnimationFrame(animate);
                        }
                    };
                    requestAnimationFrame(animate);
                    observer.disconnect();
                }
            },
            { threshold: 0.5 }
        );

        if (ref.current) {
            observer.observe(ref.current);
        }

        return () => observer.disconnect();
    }, [end, duration]);

    return { count, ref };
};


const Biodiversity: React.FC = () => {
  const mapContainer = useRef<HTMLDivElement>(null);
  const mapInstance = useRef<any>(null);

  useEffect(() => {
    if (mapContainer.current && !mapInstance.current) {
      const map = L.map(mapContainer.current, { scrollWheelZoom: false }).setView([-2.93, 115.14], 11);
      mapInstance.current = map;

      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', { 
        attribution: '&copy; OpenStreetMap contributors' 
      }).addTo(map);

      const floraIcon = L.divIcon({
        className: 'custom-div-icon',
        html: '<div style="background:#CFEAD6;border:1px solid #6DBE45;color:#254336;padding:6px 8px;border-radius:12px;font-weight:700">🌿</div>',
        iconSize: [30, 30],
        iconAnchor: [15, 15]
      });
      const faunaIcon = L.divIcon({
        className: 'custom-div-icon',
        html: '<div style="background:#D7E9F7;border:1px solid #3A8FB7;color:#254336;padding:6px 8px;border-radius:12px;font-weight:700">🐾</div>',
        iconSize: [30, 30],
        iconAnchor: [15, 15]
      });

      points.forEach(p => {
        const icon = p.type === 'flora' ? floraIcon : faunaIcon;
        L.marker([p.lat, p.lng], { icon }).addTo(map)
          .bindPopup(`<b>${p.name}</b><br>Status: ${p.status}`);
      });
    }
  }, []);

  const floraCount = points.filter(p => p.type === 'flora').length;
  const faunaCount = points.filter(p => p.type === 'fauna').length;
  const protectedCount = points.filter(p => p.status === 'Dilindungi').length;

  const animatedFlora = useCountUp(floraCount);
  const animatedFauna = useCountUp(faunaCount);
  const animatedProtected = useCountUp(protectedCount);


  return (
    <section id="biodiv" className="py-16 md:py-24 bg-cream">
      <div className="max-w-screen-xl mx-auto px-6">
        <Reveal>
            <h2 className="font-display text-3xl md:text-4xl font-bold">Keanekaragaman Hayati</h2>
        </Reveal>
        <Reveal>
            <p className="mt-3 text-lg text-muted max-w-2xl leading-relaxed">
            Menjaga kehidupan dengan data dan AI. Lihat peta sebaran spesies serta statistik konservasi.
            </p>
        </Reveal>
        <div className="mt-12 grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
            <Reveal>
                <div ref={mapContainer} className="w-full h-[420px] rounded-2xl border border-gray-300 shadow-lg" aria-label="Peta Keanekaragaman Hayati"></div>
            </Reveal>
            <div className="flex flex-col gap-6">
                <Reveal>
                    <div className="bg-white/70 border border-gray-200 rounded-2xl p-6 shadow-lg shadow-black/5">
                        <h3 className="text-xl font-semibold text-ink">Status Konservasi</h3>
                        <p className="mt-2 text-muted">Ringkasan spesies dilindungi, endemik, dan indikasi invasif (data contoh).</p>
                        <div className="mt-4 flex gap-3 flex-wrap">
                            <span className="inline-flex items-center gap-2 px-3 py-2 rounded-full bg-green-100/70 border border-green-200/80 text-ink">🌿 Flora: <b ref={animatedFlora.ref}>{animatedFlora.count}</b></span>
                            <span className="inline-flex items-center gap-2 px-3 py-2 rounded-full bg-blue-100/70 border border-blue-200/80 text-ink">🐾 Fauna: <b ref={animatedFauna.ref}>{animatedFauna.count}</b></span>
                            <span className="inline-flex items-center gap-2 px-3 py-2 rounded-full bg-yellow-100/70 border border-yellow-300/80 text-ink">🛡️ Dilindungi: <b ref={animatedProtected.ref}>{animatedProtected.count}</b></span>
                        </div>
                         <div className="mt-6">
                            <a className="inline-flex items-center gap-2 px-4 py-2 rounded-xl font-semibold cursor-pointer transition-transform duration-200 bg-white text-ink shadow-md shadow-black/5 border border-gray-200/80 hover:-translate-y-0.5" href="#">
                                Unduh Data Biodiversity
                            </a>
                        </div>
                    </div>
                </Reveal>
                 <Reveal>
                    <div className="bg-white/70 border border-gray-200 rounded-2xl p-6 shadow-lg shadow-black/5">
                        <h3 className="text-xl font-semibold text-ink">Spesies Sorotan</h3>
                        <p className="mt-2 text-muted">Shorea sp. (Dipterocarpaceae), Nasalis larvatus (Bekantan), Acacia mangium, dll.</p>
                    </div>
                </Reveal>
            </div>
        </div>
      </div>
    </section>
  );
};

export default Biodiversity;