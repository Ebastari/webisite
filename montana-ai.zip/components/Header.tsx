import React, { useState } from 'react';

const navLinks = [
  { href: '#teknologi', label: 'Teknologi AI' },
  { href: '#nursery', label: 'Nursery' },
  { href: '#biodiv', label: 'Keanekaragaman Hayati' },
  { href: '#data', label: 'Data Publik' },
  { href: '#artikel', label: 'Artikel' },
  { href: '#kontak', label: 'Kontak' },
];

const Header: React.FC = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };
  
  const closeMenu = () => {
    setIsMenuOpen(false);
  }

  return (
    <>
      <header className="sticky top-0 z-50 bg-white/80 backdrop-blur-md border-b border-gray-200/80">
        <div className="max-w-screen-xl mx-auto px-6 py-3 flex items-center justify-between">
          <a className="flex items-center gap-3" href="#home" aria-label="Beranda Montana AI">
            <img src="https://raw.githubusercontent.com/google/material-design-icons/master/src/image/eco/materialicons/48px.svg" alt="Logo Montana AI" className="w-9 h-9 text-ink" />
            <strong className="font-display text-ink text-xl">Montana AI</strong>
          </a>
          <nav className="hidden lg:flex items-center gap-4" aria-label="Navigasi utama">
            {navLinks.map((link) => (
              <a key={link.href} href={link.href} className="px-3 py-2 rounded-lg text-ink/80 hover:text-ink font-medium transition-colors">
                {link.label}
              </a>
            ))}
            <a className="ml-4 inline-flex items-center gap-2 px-4 py-2 rounded-xl border border-transparent font-semibold cursor-pointer transition-transform duration-200 bg-gradient-to-r from-brand to-brand-2 text-[#053a35] shadow-lg shadow-brand/20 hover:-translate-y-0.5" href="#">
              Buka Aplikasi AI
            </a>
          </nav>
          <button
            className="lg:hidden inline-flex items-center gap-2 bg-white border border-gray-200 rounded-lg px-3 py-2 text-ink"
            onClick={toggleMenu}
            aria-controls="mobileNav"
            aria-expanded={isMenuOpen}
          >
            <i className="fa-solid fa-bars"></i>
            Menu
          </button>
        </div>
      </header>

      {/* MOBILE NAV */}
      {isMenuOpen && (
        <div id="mobileNav" className="lg:hidden fixed inset-0 bg-black/30 z-40" onClick={closeMenu}>
            <div className="absolute top-20 left-4 right-4 bg-white rounded-2xl shadow-xl p-5 border border-gray-200" onClick={(e) => e.stopPropagation()}>
                <nav className="flex flex-col gap-3 text-center">
                    {navLinks.map((link) => (
                    <a key={link.href} href={link.href} onClick={closeMenu} className="block py-2 rounded-md font-medium hover:bg-green-100/60 transition-colors">
                        {link.label}
                    </a>
                    ))}
                    <a className="mt-4 inline-flex items-center justify-center gap-2 px-4 py-3 rounded-xl border border-transparent font-semibold cursor-pointer transition-transform duration-200 bg-gradient-to-r from-brand to-brand-2 text-[#053a35] shadow-lg shadow-brand/20" href="#">
                        Buka Aplikasi AI
                    </a>
                </nav>
            </div>
        </div>
      )}
    </>
  );
};

export default Header;