import React from 'react';
import Reveal from './Reveal';

const technologies = [
    { title: "AI Vision", description: "Model klasifikasi citra untuk mendeteksi kesehatan daun dan anomali pertumbuhan." },
    { title: "Data Pipeline", description: "Automasi ingest dari form lapangan, validasi, hingga visualisasi pelaporan." },
    { title: "Interaktif Map", description: "Google Earth & AppSheet Maps untuk rencana dan realisasi penanaman." },
];

const Technology: React.FC = () => {
  return (
    <section id="teknologi" className="py-16 md:py-24 bg-gradient-to-b from-white to-green-50/50">
      <div className="max-w-screen-xl mx-auto px-6">
        <Reveal>
          <h2 className="font-display text-3xl md:text-4xl font-bold">Teknologi & Arsitektur</h2>
        </Reveal>
        <Reveal>
          <p className="mt-3 text-lg text-muted max-w-2xl leading-relaxed">
            Alur data sensor → analitik → laporan & peta, dirancang untuk keandalan dan kemudahan audit.
          </p>
        </Reveal>
        <div className="mt-12 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {technologies.map((tech, index) => (
            <Reveal key={index}>
              <div className="bg-white border border-gray-200/80 rounded-2xl p-6 shadow-lg shadow-black/5 h-full">
                <h3 className="text-xl font-semibold text-ink">{tech.title}</h3>
                <p className="mt-2 text-muted">{tech.description}</p>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Technology;