import React from 'react';

const SocialLink: React.FC<{href: string, icon: string, label: string}> = ({href, icon, label}) => (
    <a href={href} aria-label={label} target="_blank" rel="noopener noreferrer" className="text-white/70 hover:text-brand transition-colors">
        <i className={`fa-brands ${icon} text-xl`}></i>
    </a>
);

const Footer: React.FC = () => {
  return (
    <footer role="contentinfo" className="bg-[#0F2027] text-[#EAF6F3] mt-4">
      <div className="max-w-screen-xl mx-auto px-6 py-10">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center md:text-left">
            <div className="md:col-span-1">
                <a className="inline-flex items-center gap-3 justify-center md:justify-start" href="#home" aria-label="Beranda Montana AI">
                    <img src="https://raw.githubusercontent.com/google/material-design-icons/master/src/image/eco/materialicons/48px.svg" alt="Logo Montana AI" className="w-9 h-9 text-white/80 filter brightness-0 invert" />
                    <strong className="font-display text-white text-xl">Montana AI</strong>
                </a>
                <p className="text-sm text-white/60 mt-4 max-w-xs mx-auto md:mx-0">
                    AI untuk reklamasi lahan cerdas dan manajemen nursery yang berkelanjutan.
                </p>
            </div>
            <div className="md:col-span-2 flex flex-col md:flex-row justify-between gap-8">
                <div>
                    <h4 className="font-semibold text-white/90 mb-3">Navigasi</h4>
                    <nav className="flex flex-col gap-2">
                         <a href="#teknologi" className="text-white/70 hover:text-brand">Teknologi</a>
                         <a href="#nursery" className="text-white/70 hover:text-brand">Nursery</a>
                         <a href="#biodiv" className="text-white/70 hover:text-brand">Biodiversitas</a>
                         <a href="#artikel" className="text-white/70 hover:text-brand">Artikel</a>
                    </nav>
                </div>
                 <div>
                    <h4 className="font-semibold text-white/90 mb-3">Legal</h4>
                    <nav className="flex flex-col gap-2">
                         <a href="#" className="text-white/70 hover:text-brand">Kebijakan Privasi</a>
                         <a href="#" className="text-white/70 hover:text-brand">Dokumentasi</a>
                         <a href="#" className="text-white/70 hover:text-brand">Versi AI</a>
                    </nav>
                </div>
                 <div>
                    <h4 className="font-semibold text-white/90 mb-3">Ikuti Kami</h4>
                    <div className="flex gap-5 justify-center md:justify-start">
                        <SocialLink href="#" icon="fa-twitter" label="Twitter" />
                        <SocialLink href="#" icon="fa-linkedin-in" label="LinkedIn" />
                        <SocialLink href="#" icon="fa-youtube" label="YouTube" />
                    </div>
                </div>
            </div>
        </div>
        <div className="mt-10 border-t border-white/10 pt-6 text-center text-sm text-white/60">
          <p>
            © {new Date().getFullYear()} Montana AI — PT Energi Batubara Lestari. All Rights Reserved.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;