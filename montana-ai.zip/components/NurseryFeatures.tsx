import React from 'react';
import Reveal from './Reveal';

const features = [
    { title: "Deteksi Kesehatan Daun", description: "Klasifikasi kondisi daun dari citra lapangan untuk rekomendasi tindakan cepat." },
    { title: "Pengukur Tinggi Otomatis", description: "Estimasi tinggi tanaman berbasis kamera/marker untuk pantauan pertumbuhan." },
    { title: "Laporan Bibit & Logbook", description: "Integrasi ke AppSheet & Looker Studio untuk rekap harian hingga bulanan." },
]

const NurseryFeatures: React.FC = () => {
  return (
    <section id="nursery" className="py-16 md:py-24">
      <div className="max-w-screen-xl mx-auto px-6">
        <Reveal>
          <h2 className="font-display text-3xl md:text-4xl font-bold">Modul Utama Montana AI</h2>
        </Reveal>
        <Reveal>
          <p className="mt-3 text-lg text-muted max-w-2xl leading-relaxed">
            Tiga pilar untuk operasi nursery modern: vision AI, pengukuran otomatis, dan pelaporan transparan.
          </p>
        </Reveal>
        <div className="mt-12 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feature, index) => (
            <Reveal key={index}>
                <div className="bg-white border border-gray-200/80 rounded-2xl p-6 shadow-lg shadow-black/5 h-full">
                    <h3 className="text-xl font-semibold text-ink">{feature.title}</h3>
                    <p className="mt-2 text-muted">{feature.description}</p>
                </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
};

export default NurseryFeatures;